import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';

class BLEDoorInsecureScreen extends StatefulWidget {
  const BLEDoorInsecureScreen({super.key});

  @override
  State<BLEDoorInsecureScreen> createState() => _BLEDoorInsecureScreenState();
}

class _BLEDoorInsecureScreenState extends State<BLEDoorInsecureScreen>
    with TickerProviderStateMixin {
  static const String serviceUuid = "6e400001-b5a3-f393-e0a9-e50e24dcca9e";

  BluetoothDevice? device;
  BluetoothCharacteristic? rxChar;
  BluetoothCharacteristic? txChar;

  StreamSubscription<List<ScanResult>>? scanSub;

  bool isConnecting = false;
  bool doorOpened = false;
  bool connectingNow = false;

  final TextEditingController pinController = TextEditingController();
  late AnimationController pulseController;
  late AnimationController lockAnimationController;

  String status = "Ready";
  String deviceName = "Smart Lock";
  String? lastErrorMessage;

  @override
  void initState() {
    super.initState();

    pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    lockAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
  }

  // ================= PERMISSIONS =================
  Future<void> ensurePermissions() async {
    Map<Permission, PermissionStatus> statuses = await [
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.location,
    ].request();

    if (statuses.values.any((status) => status.isDenied)) {
      setState(() {
        lastErrorMessage = "Please grant required permissions";
      });
    }
  }

  // ================= SCAN =================
  Future<void> scanAndConnect() async {
    setState(() {
      isConnecting = true;
      status = "Scanning for lock...";
      doorOpened = false;
      device = null;
      rxChar = null;
      txChar = null;
      connectingNow = false;
      lastErrorMessage = null;
    });

    try {
      await ensurePermissions();
      await FlutterBluePlus.stopScan();
      await scanSub?.cancel();

      scanSub = FlutterBluePlus.scanResults.listen((results) async {
        if (connectingNow || !mounted) return;

        for (final r in results) {
          final uuids = r.advertisementData.serviceUuids;

          if (uuids.any((u) => u.toString().toLowerCase() == serviceUuid)) {
            connectingNow = true;
            deviceName = r.device.platformName.isNotEmpty
                ? r.device.platformName
                : "Smart Lock";

            setState(() {
              status = "Found $deviceName";
            });

            await FlutterBluePlus.stopScan();
            await connectToDevice(r.device);
            return;
          }
        }
      });

      await FlutterBluePlus.startScan(
        timeout: const Duration(seconds: 15),
        androidScanMode: AndroidScanMode.lowLatency,
      );

      // Handle timeout
      Future.delayed(const Duration(seconds: 15), () {
        if (mounted && !connectingNow && isConnecting) {
          setState(() {
            status = "No devices found";
            isConnecting = false;
            lastErrorMessage = "Make sure the lock is powered on";
          });
        }
      });
    } catch (e) {
      if (mounted) {
        setState(() {
          status = "Scan failed";
          isConnecting = false;
          lastErrorMessage = e.toString();
        });
      }
    }
  }

  // ================= CONNECT =================
  Future<void> connectToDevice(BluetoothDevice d) async {
    try {
      setState(() {
        status = "Connecting...";
      });

      device = d;

      await device!.connect(
        autoConnect: false,
        timeout: const Duration(seconds: 15),
        license: License.free
      );

      await discoverServices();
    } catch (e) {
      if (mounted) {
        setState(() {
          status = "Connection failed";
          isConnecting = false;
          lastErrorMessage = "Make sure you're close to the device";
        });
      }
    }
  }

  // ================= DISCOVER =================
  Future<void> discoverServices() async {
    if (device == null || !mounted) return;

    try {
      setState(() {
        status = "Discovering services...";
      });

      final services = await device!.discoverServices();

      for (final s in services) {
        if (s.uuid.toString().toLowerCase() == serviceUuid) {
          for (final c in s.characteristics) {
            final uuid = c.uuid.toString().toLowerCase();
            if (uuid == "6e400002-b5a3-f393-e0a9-e50e24dcca9e") rxChar = c;
            if (uuid == "6e400003-b5a3-f393-e0a9-e50e24dcca9e") txChar = c;
          }
        }
      }

      if (rxChar == null || txChar == null || !mounted) {
        setState(() {
          status = "UART service not found";
          isConnecting = false;
          lastErrorMessage = "Device not compatible";
        });
        return;
      }

      await txChar!.setNotifyValue(true);

      txChar!.lastValueStream.listen((value) {
        if (!mounted) return;
        final msg = utf8.decode(value).trim();

        setState(() {
          if (msg == "OK") {
            status = "✅ Door unlocked successfully";
            doorOpened = true;
            lastErrorMessage = null;
            lockAnimationController.forward().then((_) {
              lockAnimationController.reverse();
            });
          } else if (msg == "ERROR") {
            status = "❌ Wrong PIN";
            doorOpened = false;
            lastErrorMessage = "Try again";
          } else {
            status = msg;
            doorOpened = false;
          }
        });
      });

      if (mounted) {
        setState(() {
          status = "🔗 Connected • Enter PIN";
          isConnecting = false;
          lastErrorMessage = null;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          status = "Service discovery failed";
          isConnecting = false;
          lastErrorMessage = e.toString();
        });
      }
    }
  }

  // ================= SEND PIN =================
  Future<void> sendPIN() async {
    if (rxChar == null || !mounted) return;

    final pin = pinController.text.trim();
    if (pin.length != 4) {
      setState(() {
        lastErrorMessage = "Please enter 4 digits";
      });
      return;
    }

    try {
      await rxChar!.write(utf8.encode(pin), withoutResponse: true);

      setState(() {
        status = "Verifying...";
        lastErrorMessage = null;
      });

      pinController.clear();
    } catch (e) {
      setState(() {
        lastErrorMessage = "Failed to send";
      });
    }
  }

  // ================= DISCONNECT =================
  Future<void> disconnectDevice() async {
    try {
      await device?.disconnect();
      if (mounted) {
        setState(() {
          device = null;
          rxChar = null;
          txChar = null;
          status = "Disconnected";
          doorOpened = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          lastErrorMessage = "Disconnect failed";
        });
      }
    }
  }

  bool get ready => device != null && rxChar != null && txChar != null;

  // ================= UI =================
  @override
  Widget build(BuildContext context) {
    const primary = Color(0xFF4361EE);
    const success = Color(0xFF4CC9F0);
    const error = Color(0xFFEF476F);

    return Scaffold(
      body: Container(
  decoration: BoxDecoration(
    gradient: LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [
        Colors.white,
        Colors.grey.shade50,
      ],
    ),
  ),
  child: SafeArea(
    child: SingleChildScrollView(
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      padding: EdgeInsets.fromLTRB(
        24,
        24,
        24,
        MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [

          // ================= Status Card =================
          Card(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: device != null
                          ? success.withOpacity(0.1)
                          : Colors.grey.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      device != null
                          ? Icons.bluetooth_connected
                          : Icons.bluetooth_disabled,
                      color: device != null ? success : Colors.grey,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          device != null ? deviceName : 'Not Connected',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          status,
                          style: TextStyle(
                            color: status.contains('✅')
                                ? success
                                : status.contains('❌')
                                    ? error
                                    : Colors.grey.shade600,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 30),

          // ================= Lock Animation =================
          Center(
            child: AnimatedBuilder(
              animation: lockAnimationController,
              builder: (context, child) {
                return Transform.scale(
                  scale: 1.0 + (lockAnimationController.value * 0.1),
                  child: Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: doorOpened
                          ? success.withOpacity(0.1)
                          : primary.withOpacity(0.1),
                    ),
                    child: Icon(
                      doorOpened
                          ? Icons.lock_open_rounded
                          : Icons.lock_rounded,
                      size: 100,
                      color: doorOpened ? success : primary,
                    ),
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 20),

          // ================= Error Message =================
          if (lastErrorMessage != null) ...[
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: error.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: error.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  Icon(Icons.error_outline, color: error, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      lastErrorMessage!,
                      style: TextStyle(color: error),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],

          // ================= PIN Card =================
          Card(
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  TextField(
                    controller: pinController,
                    maxLength: 4,
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 24,
                      letterSpacing: 8,
                      fontWeight: FontWeight.bold,
                    ),
                    decoration: InputDecoration(
                      hintText: "••••",
                      hintStyle: TextStyle(
                        fontSize: 24,
                        letterSpacing: 8,
                        color: Colors.grey.shade400,
                      ),
                      labelText: "Enter PIN",
                      labelStyle: TextStyle(color: primary),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide:
                            BorderSide(color: primary, width: 2),
                      ),
                      counterText: "",
                    ),
                    enabled: ready && !isConnecting,
                  ),

                  const SizedBox(height: 16),

                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed:
                          (ready && !isConnecting) ? sendPIN : null,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primary,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        "UNLOCK",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 16),

          // ================= Connect Button =================
          SizedBox(
            width: double.infinity,
            height: 50,
            child: OutlinedButton(
              onPressed: isConnecting
                  ? null
                  : (device != null
                      ? disconnectDevice
                      : scanAndConnect),
              style: OutlinedButton.styleFrom(
                foregroundColor:
                    device != null ? error : primary,
                side: BorderSide(
                  color: device != null ? error : primary,
                  width: 2,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Text(
                isConnecting
                    ? "CONNECTING..."
                    : (device != null
                        ? "DISCONNECT"
                        : "CONNECT"),
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),

          const SizedBox(height: 20),

          if (device != null)
            Center(
              child: Text(
                'Connected to: $deviceName',
                style: TextStyle(
                  color: Colors.grey.shade600,
                  fontSize: 12,
                ),
              ),
            ),
        ],
      ),
    ),
  ),
));

  }

  @override
  void dispose() {
    scanSub?.cancel();
    pinController.dispose();
    pulseController.dispose();
    lockAnimationController.dispose();
    device?.disconnect();
    super.dispose();
  }
}