import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/home_status.dart';


class BleDashboardScreen extends StatefulWidget {
  const BleDashboardScreen({super.key});

  @override
  State<BleDashboardScreen> createState() => _BleDashboardScreenState();
}

class _BleDashboardScreenState extends State<BleDashboardScreen> {

  MqttServerClient? client;
  StreamSubscription? _mqttSub;

  bool _disposing = false;
  bool connected = false;
  bool receivedNotify = false;

  DateTime _lastUiUpdate = DateTime.fromMillisecondsSinceEpoch(0);

  String selectedRoom = "room1";
  HomeStatus status = HomeStatus.initial("room1");

  final String broker = "10.146.61.134";
  final int port = 1883;

  final String statusTopic = "home/status";

  // ✅ Dynamic topic per room
  String get commandTopic => "home/$selectedRoom/command";

  @override
  void initState() {
    super.initState();
    _connectMQTT();
  }

  @override
  void dispose() {
    _disposing = true;
    _mqttSub?.cancel();
    try {
      client?.disconnect();
    } catch (_) {}
    super.dispose();
  }

  // ================= MQTT CONNECT =================
  Future<void> _connectMQTT() async {

    final mqttClient = MqttServerClient(
        broker,
        "flutter_${DateTime.now().millisecondsSinceEpoch}");

    mqttClient.port = port;
    mqttClient.keepAlivePeriod = 20;
    mqttClient.logging(on: false);
    mqttClient.autoReconnect = true;

    client = mqttClient;

    mqttClient.onConnected = () {
      if (!mounted || _disposing) return;

      debugPrint("MQTT CONNECTED");

      setState(() => connected = true);
      mqttClient.subscribe(statusTopic, MqttQos.atLeastOnce);
    };

    mqttClient.onDisconnected = () {
      if (!mounted || _disposing) return;

      debugPrint("MQTT DISCONNECTED");
      setState(() => connected = false);
    };

    try {
      await mqttClient.connect();
    } catch (_) {
      mqttClient.disconnect();
      return;
    }

    if (mqttClient.connectionStatus?.state !=
        MqttConnectionState.connected) {
      return;
    }

    _mqttSub = mqttClient.updates?.listen((events) {

      if (!mounted || _disposing) return;
      if (events.isEmpty) return;

      final rec = events.first.payload as MqttPublishMessage;
      final payload =
          MqttPublishPayload.bytesToStringAsString(rec.payload.message);

      debugPrint("📡 MQTT RX: $payload");

      try {
        final data = jsonDecode(payload);

        if (data["room"] != selectedRoom) return;

        final newStatus = HomeStatus.fromJson(data);

        final now = DateTime.now();
        if (now.difference(_lastUiUpdate).inMilliseconds < 300) return;
        _lastUiUpdate = now;

        if (newStatus == status && receivedNotify) return;

        setState(() {
          status = newStatus;
          receivedNotify = true;
        });

      } catch (e) {
        debugPrint("JSON ERROR: $e");
      }
    });
  }

  // ================= SEND COMMAND =================
  void sendCommand(String device, bool state) {
    if (client == null || !connected) return;

    final payload = {
      device: state ? "on" : "off"
    };

    final builder = MqttClientPayloadBuilder();
    builder.addString(jsonEncode(payload));

    client!.publishMessage(
      commandTopic,
      MqttQos.atLeastOnce,
      builder.payload!,
    );

    debugPrint("📤 MQTT TX → $commandTopic : ${jsonEncode(payload)}");
  }

  // ================= LOGOUT =================
  Future<void> _logout() async {
    _disposing = true;
    await _mqttSub?.cancel();
    client?.disconnect();
    await FirebaseAuth.instance.signOut();
  }

  // ================= UI =================
  @override
  Widget build(BuildContext context) {

    final isDark =
        Theme.of(context).brightness == Brightness.dark;

    final cardColor =
        isDark ? Colors.grey[900]! : Colors.white;

    return Scaffold(
      body: Container(
        color:
            isDark ? Colors.black : const Color(0xFFF5F6FA),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [

            _roomSelector(),
            const SizedBox(height: 12),

            _connectionCard(cardColor),
            const SizedBox(height: 16),

            _statusBanner(),
            const SizedBox(height: 24),

            _sectionTitle("Controls"),
            const SizedBox(height: 12),

            _controlCard(
              icon: Icons.lightbulb_outline,
              activeIcon: Icons.lightbulb,
              title: "Light",
              value: status.lightOn ?? false,
              onChanged: connected
                  ? (v) => sendCommand("light", v)
                  : null,
              cardColor: cardColor,
            ),

            if (status.heaterOn != null) ...[
              const SizedBox(height: 12),
              _controlCard(
                icon: Icons.heat_pump_outlined,
                activeIcon: Icons.heat_pump,
                title: "Heater",
                value: status.heaterOn ?? false,
                onChanged: connected
                    ? (v) => sendCommand("heater", v)
                    : null,
                cardColor: cardColor,
              ),
            ],

            const SizedBox(height: 28),
            _sectionTitle("Sensors"),
            const SizedBox(height: 12),

            if (status.temp != null)
              _sensorCard(
                icon: Icons.thermostat,
                title: "Temperature",
                value:
                    "${status.temp!.toStringAsFixed(1)} °C",
                color: Colors.redAccent,
                cardColor: cardColor,
              ),

            if (status.humidity != null)
              _sensorCard(
                icon: Icons.water_drop,
                title: "Humidity",
                value: "${status.humidity} %",
                color: Colors.blueAccent,
                cardColor: cardColor,
              ),

            if (status.pressure != null)
              _sensorCard(
                icon: Icons.speed,
                title: "Pressure",
                value: "${status.pressure} hPa",
                color: Colors.deepPurple,
                cardColor: cardColor,
              ),
          ],
        ),
      ),
    );
  }

  Widget _roomSelector() {
    return Row(
      mainAxisAlignment:
          MainAxisAlignment.spaceEvenly,
      children: ["room1", "room2", "room3"]
          .map((room) {
        final selected = room == selectedRoom;
        return ChoiceChip(
          label: Text(room.toUpperCase()),
          selected: selected,
          onSelected: (_) {
            setState(() {
              selectedRoom = room;
              status = HomeStatus.initial(room);
              receivedNotify = false;
            });
          },
        );
      }).toList(),
    );
  }

  Widget _connectionCard(Color cardColor) {
    return Card(
      color: cardColor,
      child: ListTile(
        leading: Icon(
          connected
              ? Icons.cloud_done
              : Icons.cloud_off,
          color:
              connected ? Colors.green : Colors.red,
        ),
        title: Text(connected
            ? "Connected to MQTT"
            : "Disconnected"),
      ),
    );
  }

  Widget _statusBanner() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: receivedNotify
            ? Colors.green.withOpacity(0.15)
            : Colors.orange.withOpacity(0.15),
        borderRadius:
            BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Icon(
            receivedNotify
                ? Icons.check_circle
                : Icons.schedule,
            color: receivedNotify
                ? Colors.green
                : Colors.orange,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(receivedNotify
                ? "Live data received"
                : "Waiting for device data..."),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Text(title,
        style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold));
  }

  Widget _controlCard({
    required IconData icon,
    required IconData activeIcon,
    required String title,
    required bool value,
    required Function(bool)? onChanged,
    required Color cardColor,
  }) {
    return Card(
      color: cardColor,
      child: ListTile(
        leading:
            Icon(value ? activeIcon : icon),
        title: Text(title),
        trailing:
            Switch(value: value, onChanged: onChanged),
      ),
    );
  }

  Widget _sensorCard({
    required IconData icon,
    required String title,
    required String value,
    required Color color,
    required Color cardColor,
  }) {
    return Card(
      color: cardColor,
      child: ListTile(
        leading: Icon(icon, color: color),
        title: Text(title),
        trailing: Text(value,
            style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16)),
      ),
    );
  }
}
