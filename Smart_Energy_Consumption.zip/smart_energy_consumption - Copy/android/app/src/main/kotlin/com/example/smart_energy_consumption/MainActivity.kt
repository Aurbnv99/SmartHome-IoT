package com.example.smart_energy_consumption

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
