import 'package:flutter/material.dart';

class EnergyColors {
  static const Color primaryEnergy = Color(0xFF00BFA5);
  static const Color secondaryEnergy = Color(0xFF2962FF);
  static const Color alert = Color(0xFFFF6B6B);

  static const Color background = Color(0xFFF8F9FA);
  static const Color surface = Color(0xFFFFFFFF);

  static const Color textPrimary = Color(0xFF212121);
  static const Color textSecondary = Color(0xFF616161);

  static const Color inactive = Color(0xFF9E9E9E);
  static const Color inactiveBg = Color(0xFFF5F5F5);

  static const Map<String, Color> category = {
    'time': Color(0xFF2962FF),
    'device': Color(0xFFAB47BC),
    'consumption': Color(0xFF00BFA5),
    'cost': Color(0xFFFFA726),
  };
}
