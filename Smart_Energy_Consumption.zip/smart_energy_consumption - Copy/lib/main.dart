import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:smart_energy_consumption/models/app_notification.dart';
import 'package:smart_energy_consumption/services/notification_service.dart';

import 'firebase_options.dart';
import 'screens/login_screen.dart';
import 'screens/main_navigation_screen.dart';
import 'screens/ble_dashboard_screen.dart';

/// 🔔 Background handler (must be top-level)
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  debugPrint("🔔 Background Message: ${message.notification?.title}");
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // 🔔 Register background handler
  FirebaseMessaging.onBackgroundMessage(
      _firebaseMessagingBackgroundHandler);

  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  final FirebaseMessaging _messaging = FirebaseMessaging.instance;

  @override
  void initState() {
    super.initState();
    _initFCM();
  }

  Future<void> _initFCM() async {

    // 🔐 Request permission (important for Android 13+)
    NotificationSettings settings =
        await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    debugPrint("🔔 Permission: ${settings.authorizationStatus}");

    // 📱 Get device token
    String? token = await _messaging.getToken();

    debugPrint("🔥 DEVICE TOKEN:");
    debugPrint(token);

    // 🔁 Listen for foreground messages
   FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
  final title = message.notification?.title ?? "Notification";
  final body = message.notification?.body ?? "";

  debugPrint("📩 Foreground message: $title");

  final notification = AppNotification(
    title: title,
    body: body,
    timestamp: DateTime.now(),
  );

  await NotificationService.saveNotification(notification);
});

    // 🔁 When user taps notification
    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      debugPrint("📲 Notification clicked");
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,

      routes: {
        '/login': (context) => const LoginScreen(),
        '/dashboard': (context) => const BleDashboardScreen(),
      },

      home: const AuthWrapper(),
    );
  }
}

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {

        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        if (snapshot.hasData) {
          return const MainNavigationScreen();
        }

        return const LoginScreen();
      },
    );
  }
}
