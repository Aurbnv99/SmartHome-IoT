import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_notification.dart';

class NotificationService {
  static const String _key = "saved_notifications";

  // 🔹 Save new notification
  static Future<void> saveNotification(AppNotification notification) async {
    final prefs = await SharedPreferences.getInstance();
    final existing = await getNotifications();

    existing.insert(0, notification); // newest first

    final encoded =
        existing.map((n) => jsonEncode(n.toJson())).toList();

    await prefs.setStringList(_key, encoded);
  }

  // 🔹 Load all notifications
  static Future<List<AppNotification>> getNotifications() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getStringList(_key) ?? [];

    return data
        .map((e) => AppNotification.fromJson(jsonDecode(e)))
        .toList();
  }

  // 🔹 Clear all
  static Future<void> clearNotifications() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }
}
