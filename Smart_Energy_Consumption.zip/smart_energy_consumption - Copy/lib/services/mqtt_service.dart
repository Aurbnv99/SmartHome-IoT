import 'dart:convert';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';

class MqttService {
  late MqttServerClient client;

  // 🔹 States
  Function(String topic, dynamic value)? onMessage;
  
  Future<void> connect() async {
    client = MqttServerClient(
      '10.146.61.236', // 🔴 IP تبع Mosquitto (PC)
      'flutter_client_${DateTime.now().millisecondsSinceEpoch}',
    );

    client.port = 1883;
    client.keepAlivePeriod = 20;
    client.logging(on: false);
    client.onConnected = () => print('✅ MQTT Connected');
    client.onDisconnected = () => print('❌ MQTT Disconnected');

    final connMess = MqttConnectMessage()
        .withClientIdentifier(client.clientIdentifier!)
        .startClean()
        .withWillQos(MqttQos.atLeastOnce);

    client.connectionMessage = connMess;

    try {
      await client.connect();
    } catch (e) {
      print('❌ MQTT connect error: $e');
      client.disconnect();
      return;
    }

    // 🔔 Subscribe
    _subscribe('home/+/+/status');
    _subscribe('home/+/+/sensor');

    client.updates!.listen((events) {
      final recMess = events[0].payload as MqttPublishMessage;
      final payload =
          MqttPublishPayload.bytesToStringAsString(recMess.payload.message);

      final topic = events[0].topic;

      try {
        final data = jsonDecode(payload);
        onMessage?.call(topic, data['value']);
      } catch (_) {
        onMessage?.call(topic, payload);
      }
    });
  }

  void _subscribe(String topic) {
    client.subscribe(topic, MqttQos.atMostOnce);
    print('🔔 Subscribed to $topic');
  }

  void publish(String topic, Map<String, dynamic> payload) {
    final builder = MqttClientPayloadBuilder();
    builder.addString(jsonEncode(payload));
    client.publishMessage(topic, MqttQos.atMostOnce, builder.payload!);
  }
}
