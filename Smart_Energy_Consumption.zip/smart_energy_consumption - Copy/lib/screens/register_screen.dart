import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen>
    with SingleTickerProviderStateMixin {
  final emailCtrl = TextEditingController();
  final passCtrl = TextEditingController();
  final confirmPassCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool loading = false;
  bool obscurePassword = true;
  bool obscureConfirmPassword = true;
  String? error;

  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _slideAnimation;

  // 🎨 Colors (SAME AS LOGIN)
  static const Color primaryColor = Color(0xFF0066CC);
  static const Color secondaryColor = Color(0xFF00B894);
  static const Color backgroundColor = Color(0xFFF8FAFC);
  static const Color surfaceColor = Colors.white;
  static const Color textPrimary = Color(0xFF1A2B3C);
  static const Color textSecondary = Color(0xFF64748B);
  static const Color errorColor = Color(0xFFEF4444);

  static const TextStyle titleStyle = TextStyle(
    fontSize: 32,
    fontWeight: FontWeight.w700,
    color: textPrimary,
    letterSpacing: -0.5,
  );
  static const TextStyle buttonStyle = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w600,
    color: Colors.white,
    letterSpacing: 0.5,
  );
  static const TextStyle subtitleStyle = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w400,
    color: textSecondary,
    height: 1.5,
  );

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeOutCubic,
      ),
    );

    _slideAnimation = Tween<double>(begin: 20, end: 0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeOutCubic,
      ),
    );

    Future.delayed(const Duration(milliseconds: 200), () {
      if (mounted) _animationController.forward();
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> register() async {
    setState(() {
      error = null;
      loading = true;
    });

    if (!_formKey.currentState!.validate()) {
      setState(() => loading = false);
      return;
    }

    try {
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: emailCtrl.text.trim(),
        password: passCtrl.text.trim(),
      );
      Navigator.pop(context);
    } on FirebaseAuthException catch (e) {
      setState(() => error = e.message);
    }

    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            bool isMobile = constraints.maxWidth < 600;

            return SingleChildScrollView(
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: constraints.maxHeight),
                child: IntrinsicHeight(
                  child: Padding(
                    padding: isMobile
                        ? const EdgeInsets.all(20)
                        : const EdgeInsets.symmetric(
                            horizontal: 80, vertical: 40),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // 🔹 Branding (SAME AS LOGIN)
                        _buildBrandingSection(isMobile),

                        const SizedBox(height: 48),

                        // 🔹 Register Card
                        Center(
                          child: Container(
                            constraints:
                                const BoxConstraints(maxWidth: 480),
                            child: AnimatedBuilder(
                              animation: _animationController,
                              builder: (context, child) {
                                return Opacity(
                                  opacity: _fadeAnimation.value,
                                  child: Transform.translate(
                                    offset:
                                        Offset(0, _slideAnimation.value),
                                    child: child,
                                  ),
                                );
                              },
                              child: Card(
                                elevation: 8,
                                shape: RoundedRectangleBorder(
                                  borderRadius:
                                      BorderRadius.circular(24),
                                  side: BorderSide(
                                      color: Colors.grey.shade100),
                                ),
                                color: surfaceColor,
                                child: Padding(
                                  padding: const EdgeInsets.all(32),
                                  child: Form(
                                    key: _formKey,
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          'Create Account',
                                          style:buttonStyle,
                                       
                                        ),
                                        const SizedBox(height: 8),
                                        Text(
                                          'Create an account to monitor your power consumption',
                                          style: subtitleStyle,
                                          textAlign: TextAlign.center,
                                        ),

                                        const SizedBox(height: 32),

                                        // Email
                                        TextFormField(
                                          controller: emailCtrl,
                                          decoration:
                                              const InputDecoration(
                                            labelText: 'Email Address',
                                            prefixIcon: Icon(
                                                Icons.email_outlined),
                                          ),
                                          keyboardType:
                                              TextInputType.emailAddress,
                                          validator: (v) {
                                            if (v == null || v.isEmpty) {
                                              return 'Please enter your email';
                                            }
                                            if (!RegExp(
                                                    r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')
                                                .hasMatch(v)) {
                                              return 'Please enter a valid email';
                                            }
                                            return null;
                                          },
                                        ),

                                        const SizedBox(height: 20),

                                        // Password
                                        TextFormField(
                                          controller: passCtrl,
                                          obscureText: obscurePassword,
                                          decoration: InputDecoration(
                                            labelText: 'Password',
                                            prefixIcon: const Icon(
                                                Icons.lock_outline),
                                            suffixIcon: IconButton(
                                              icon: Icon(obscurePassword
                                                  ? Icons
                                                      .visibility_outlined
                                                  : Icons
                                                      .visibility_off_outlined),
                                              onPressed: () {
                                                setState(() {
                                                  obscurePassword =
                                                      !obscurePassword;
                                                });
                                              },
                                            ),
                                          ),
                                          validator: (v) {
                                            if (v == null || v.length < 6) {
                                              return 'Password must be at least 6 characters';
                                            }
                                            return null;
                                          },
                                        ),

                                        const SizedBox(height: 20),

                                        // Confirm Password
                                        TextFormField(
                                          controller: confirmPassCtrl,
                                          obscureText:
                                              obscureConfirmPassword,
                                          decoration: InputDecoration(
                                            labelText:
                                                'Confirm Password',
                                            prefixIcon: const Icon(
                                                Icons.lock_outline),
                                            suffixIcon: IconButton(
                                              icon: Icon(
                                                  obscureConfirmPassword
                                                      ? Icons
                                                          .visibility_outlined
                                                      : Icons
                                                          .visibility_off_outlined),
                                              onPressed: () {
                                                setState(() {
                                                  obscureConfirmPassword =
                                                      !obscureConfirmPassword;
                                                });
                                              },
                                            ),
                                          ),
                                          validator: (v) {
                                            if (v != passCtrl.text) {
                                              return 'Passwords do not match';
                                            }
                                            return null;
                                          },
                                        ),

                                        const SizedBox(height: 24),

                                        if (error != null)
                                          Text(
                                            error!,
                                            style: const TextStyle(
                                              color: errorColor,
                                              fontWeight:
                                                  FontWeight.w500,
                                            ),
                                          ),

                                        if (error != null)
                                          const SizedBox(height: 16),

                                        SizedBox(
                                          width: double.infinity,
                                          height: 56,
                                          child: ElevatedButton(
                                            onPressed:
                                                loading ? null : register,
                                            child: loading
                                                ? const CircularProgressIndicator(
                                                    color: Colors.white,
                                                  )
                                                : const Text(
                                                    'Create Account'),
                                          ),
                                        ),

                                        const SizedBox(height: 32),

                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Text(
                                              'Already have an account?',
                                              style: subtitleStyle.copyWith(
                                                  fontSize: 14),
                                            ),
                                            TextButton(
                                              onPressed: () =>
                                                  Navigator.pop(context),
                                              child:
                                                  const Text('Sign In'),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),

                        const SizedBox(height: 40),

                        // 🔹 Footer (SAME AS LOGIN)
                        Align(
                          alignment: Alignment.center,
                          child: Text(
                            '© 2024 PowerMonitor Network. All rights reserved.',
                            style:
                                subtitleStyle.copyWith(fontSize: 12),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  // 🔹 SAME branding as Login
  Widget _buildBrandingSection(bool isMobile) {
    return Center(
      child: Column(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [primaryColor, secondaryColor],
              ),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(Icons.bolt, color: Colors.white),
          ),
          const SizedBox(height: 12),
          Text(
            'PowerMonitor',
            style: TextStyle(
              fontSize: isMobile ? 22 : 24,
              fontWeight: FontWeight.w800,
              color: textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}
