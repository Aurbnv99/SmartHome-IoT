import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';

class BLEDoorScreen extends StatefulWidget {
  const BLEDoorScreen({super.key});

  @override
  State<BLEDoorScreen> createState() => _BLEDoorScreenState();
}

class _BLEDoorScreenState extends State<BLEDoorScreen>
    with TickerProviderStateMixin {

  //  UUIDs — مطابقين لكود ESP32
  static const String serviceUuid =
      "4fafc201-1fb5-459e-8fcc-c5c9c331914b";

  static const String characteristicUuid =
      "beb5483e-36e1-4688-b7f5-ea07361b26a8";

  BluetoothDevice? device;
  BluetoothCharacteristic? characteristic;

  StreamSubscription<List<ScanResult>>? scanSub;

  bool isConnecting = false;
  bool doorOpened = false;

  final TextEditingController pinController = TextEditingController();
  late AnimationController lockAnimationController;

  String status = "Ready";
  String deviceName = "ESP32-Room3(Gate)";
  String? lastErrorMessage;

  @override
  void initState() {
    super.initState();

    lockAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
  }

  // ================= PERMISSIONS =================
  Future<void> ensurePermissions() async {
    await [
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.location,
    ].request();
  }

  // ================= SCAN =================
  Future<void> scanAndConnect() async {
    setState(() {
      isConnecting = true;
      status = "Scanning...";
      lastErrorMessage = null;
      doorOpened = false;
    });

    try {
      await ensurePermissions();
      await FlutterBluePlus.stopScan();
      await scanSub?.cancel();

      scanSub = FlutterBluePlus.scanResults.listen((results) async {
        for (final r in results) {
          final uuids = r.advertisementData.serviceUuids;

          if (r.device.platformName == "ESP32-Room3(Gate)"||uuids
              .any((u) => u.toString().toLowerCase() == serviceUuid)) {

            await FlutterBluePlus.stopScan();

            device = r.device;
            deviceName = r.device.platformName.isNotEmpty
                ? r.device.platformName
                : "ESP32-Room3(Gate)";

            setState(() {
              status = "Found $deviceName";
            });

            await connectToDevice();
            return;
          }
        }
      });

      await FlutterBluePlus.startScan(
        timeout: const Duration(seconds: 15),
        androidScanMode: AndroidScanMode.lowLatency,
      );
    } catch (e) {
      setState(() {
        status = "Scan failed";
        isConnecting = false;
        lastErrorMessage = e.toString();
      });
    }
  }

  // ================= CONNECT =================
  Future<void> connectToDevice() async {
    if (device == null) return;

    try {
      setState(() {
        status = "Connecting...";
      });

      await device!.connect(
        autoConnect: false,
        timeout: const Duration(seconds: 15),
        license: License.free,
      );

      await discoverServices();
    } catch (e) {
      setState(() {
        status = "Connection failed";
        isConnecting = false;
        lastErrorMessage = e.toString();
      });
    }
  }

  // ================= DISCOVER =================
  Future<void> discoverServices() async {
    if (device == null) return;

    final services = await device!.discoverServices();

    for (final s in services) {
      if (s.uuid.toString().toLowerCase() == serviceUuid) {
        for (final c in s.characteristics) {
          if (c.uuid.toString().toLowerCase() == characteristicUuid) {
            characteristic = c;
          }
        }
      }
    }

    if (characteristic == null) {
      setState(() {
        status = "Characteristic not found";
        isConnecting = false;
      });
      return;
    }

    // Enable notifications
    await characteristic!.setNotifyValue(true);

    characteristic!.lastValueStream.listen((value) {
      final msg = utf8.decode(value).trim();

      if (!mounted) return;

      setState(() {
        if (msg == "OK") {
          status = " Door Unlocked";
          doorOpened = true;
          lockAnimationController.forward().then((_) {
            lockAnimationController.reverse();
          });
        } else if (msg == "ERROR") {
          status = "Wrong PIN";
          doorOpened = false;
        }
      });
    });

    setState(() {
      status = "Connected • Enter PIN";
      isConnecting = false;
    });
  }

  // ================= SEND PIN =================
  Future<void> sendPIN() async {
    if (characteristic == null) return;

    final pin = pinController.text.trim();

    if (pin.length != 4) {
      setState(() {
        lastErrorMessage = "Enter 4 digits";
      });
      return;
    }

    await characteristic!.write(
      utf8.encode(pin),
      withoutResponse: false,
    );

    setState(() {
      status = "Verifying...";
      lastErrorMessage = null;
    });

    pinController.clear();
  }

  // ================= DISCONNECT =================
  Future<void> disconnect() async {
    await device?.disconnect();
    setState(() {
      device = null;
      characteristic = null;
      status = "Disconnected";
      doorOpened = false;
    });
  }

  bool get ready => device != null && characteristic != null;

  // ================= UI =================
  @override
  Widget build(BuildContext context) {
    const primary = Color(0xFF4361EE);
    const success = Color(0xFF4CC9F0);
    const error = Color(0xFFEF476F);

return Scaffold(
  resizeToAvoidBottomInset: true,   
  body: SafeArea(
    child: SingleChildScrollView(
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      padding: EdgeInsets.fromLTRB(
       30,
        30,
        30,
        MediaQuery.of(context).viewInsets.bottom + 30,
      ),
      child: Column(
          children: [

            const SizedBox(height: 20),

            Icon(
              doorOpened ? Icons.lock_open : Icons.lock,
              size: 100,
              color: doorOpened ? success : primary,
            ),

            const SizedBox(height: 20),

            Text(
              status,
              style: TextStyle(
                fontSize: 16,
                color: status.contains("❌")
                    ? error
                    : status.contains("✅")
                        ? success
                        : Colors.black,
              ),
            ),

            const SizedBox(height: 30),

            TextField(
              controller: pinController,
              maxLength: 4,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              decoration: const InputDecoration(
                labelText: "Enter PIN",
                counterText: "",
              ),
              enabled: ready,
            ),

            const SizedBox(height: 20),

            ElevatedButton(
              onPressed: ready ? sendPIN : null,
              child: const Text("UNLOCK"),
            ),

            const SizedBox(height: 20),

            OutlinedButton(
              onPressed: isConnecting
                  ? null
                  : (device != null ? disconnect : scanAndConnect),
              child: Text(
                device != null ? "DISCONNECT" : "CONNECT",
              ),
            ),
          ],
         
      ),
    ),
  ),
);
  }
  @override
  void dispose() {
    scanSub?.cancel();
    device?.disconnect();
    pinController.dispose();
    lockAnimationController.dispose();
    super.dispose();
  }
}