  import 'package:flutter/material.dart';
  import 'package:firebase_auth/firebase_auth.dart';
  import 'register_screen.dart';

  class LoginScreen extends StatefulWidget {
    const LoginScreen({super.key});

    @override
    State<LoginScreen> createState() => _LoginScreenState();
  }

  class _LoginScreenState extends State<LoginScreen> with SingleTickerProviderStateMixin {
    final emailCtrl = TextEditingController();
    final passCtrl = TextEditingController();
    final _formKey = GlobalKey<FormState>();
    
    bool loading = false;
    bool obscurePassword = true;
    bool emailError = false;
    bool passwordError = false;
    String? error;
    
    late AnimationController _animationController;
    late Animation<double> _fadeAnimation;
    late Animation<double> _slideAnimation;
    
    // Color Scheme - Energy/Tech Theme
    static const Color primaryColor = Color(0xFF0066CC); // Electric blue
    static const Color secondaryColor = Color(0xFF00B894); // 🔽 غمّقنا الأخضر شوي
    static const Color backgroundColor = Color(0xFFF8FAFC);
    static const Color surfaceColor = Colors.white;
    static const Color textPrimary = Color(0xFF1A2B3C);
    static const Color textSecondary = Color(0xFF64748B);
    static const Color errorColor = Color(0xFFEF4444);
    static const Color successColor = Color(0xFF10B981);
    static const Color subtleBlue = Color(0xFF5D7A9A); // 🔽 لون جديد للـ Forgot Password

    // Typography
    static const TextStyle titleStyle = TextStyle(
      fontSize: 32,
      fontWeight: FontWeight.w700,
      color: textPrimary,
      letterSpacing: -0.5,
    );
    
    static const TextStyle subtitleStyle = TextStyle(
      fontSize: 16,
      fontWeight: FontWeight.w400,
      color: textSecondary,
      height: 1.5,
    );
    
    static const TextStyle labelStyle = TextStyle(
      fontSize: 14,
      fontWeight: FontWeight.w500,
      color: textPrimary,
    );
    
    static const TextStyle buttonStyle = TextStyle(
      fontSize: 16,
      fontWeight: FontWeight.w600,
      color: Colors.white,
      letterSpacing: 0.5,
    );

    @override
    void initState() {
      super.initState();
      
      // 🔽 Animation Controller للـ Fade-in
      _animationController = AnimationController(
        duration: const Duration(milliseconds: 600),
        vsync: this,
      );
      
      _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(
          parent: _animationController,
          curve: Curves.easeOutCubic,
        ),
      );
      
      _slideAnimation = Tween<double>(begin: 20.0, end: 0.0).animate(
        CurvedAnimation(
          parent: _animationController,
          curve: Curves.easeOutCubic,
        ),
      );
      
      // 🔽 بدء الـ Animation بعد تأخير بسيط
      Future.delayed(const Duration(milliseconds: 200), () {
        if (mounted) {
          _animationController.forward();
        }
      });
    }

    @override
    void dispose() {
      _animationController.dispose();
      super.dispose();
    }

 Future<void> login() async {
  setState(() {
    emailError = false;
    passwordError = false;
    error = null;
  });

  if (!_formKey.currentState!.validate()) {
    if (emailCtrl.text.isEmpty) {
      setState(() => emailError = true);
    }
    if (passCtrl.text.isEmpty) {
      setState(() => passwordError = true);
    }
    return;
  }

  setState(() => loading = true);

  try {
    await FirebaseAuth.instance.signInWithEmailAndPassword(
      email: emailCtrl.text.trim(),
      password: passCtrl.text.trim(),
    );

    // ❌ لا Navigator
    // ❌ لا تسجيل دخول مرة ثانية
    // StreamBuilder في main هو يلي رح ينقلك

  } on FirebaseAuthException catch (e) {
    if (!mounted) return;

    setState(() {
      error = _getUserFriendlyError(e.code);
    });
  } catch (e) {
    if (!mounted) return;

    setState(() {
      error = "Something went wrong. Please try again.";
    });
  }

  if (mounted) {
    setState(() => loading = false);
  }
}

    String _getUserFriendlyError(String code) {
      switch (code) {
        case 'user-not-found':
          return 'No account found with this email';
        case 'wrong-password':
          return 'Incorrect password. Please try again';
        case 'invalid-email':
          return 'Please enter a valid email address';
        case 'user-disabled':
          return 'This account has been disabled';
        case 'too-many-requests':
          return 'Too many attempts. Please try again later';
        default:
          return 'Login failed. Please check your credentials';
      }
    }

    // 🔽 دالة للتحقق من الحقول عند التغيير
    void _validateField(String field) {
      if (!loading) {
        setState(() {
          if (field == 'email') {
            emailError = emailCtrl.text.isEmpty;
          } else if (field == 'password') {
            passwordError = passCtrl.text.isEmpty;
          }
        });
      }
    }

    @override
    Widget build(BuildContext context) {
      return Scaffold(
        backgroundColor: backgroundColor,
        body: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              bool isMobile = constraints.maxWidth < 600;
              
              return SingleChildScrollView(
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    minHeight: constraints.maxHeight,
                  ),
                  child: IntrinsicHeight(
                    child: Padding(
                      padding: isMobile 
                        ? const EdgeInsets.all(20)
                        : const EdgeInsets.symmetric(horizontal: 80, vertical: 40),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Logo and Branding Section
                          _buildBrandingSection(isMobile),
                          
                          const SizedBox(height: 48),
                          
                          // Login Form with Animation
                          Expanded(
                            child: Center(
                              child: Container(
                                constraints: const BoxConstraints(maxWidth: 480),
                                child: AnimatedBuilder(
                                  animation: _animationController,
                                  builder: (context, child) {
                                    return Opacity(
                                      opacity: _fadeAnimation.value,
                                      child: Transform.translate(
                                        offset: Offset(0, _slideAnimation.value),
                                        child: child,
                                      ),
                                    );
                                  },
                                  child: Card(
                                    elevation: 8,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(24),
                                      side: BorderSide(color: Colors.grey.shade100),
                                    ),
                                    color: surfaceColor,
                                    child: Padding(
                                      padding: const EdgeInsets.all(32),
                                      child: Form(
                                        key: _formKey,
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Text(
                                              'Welcome Back',
                                              style: titleStyle.copyWith(fontSize: 28),
                                            ),
                                            const SizedBox(height: 8),
                                            Text(
                                              'Sign in to monitor your power consumption',
                                              style: subtitleStyle,
                                              textAlign: TextAlign.center,
                                            ),
                                            const SizedBox(height: 32),
                                            
                                            // Email Field with Validation
                                            Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                TextFormField(
                                                  controller: emailCtrl,
                                                  decoration: InputDecoration(
                                                    labelText: 'Email Address',
                                                    labelStyle: labelStyle,
                                                    prefixIcon: Icon(Icons.email_outlined, color: textSecondary),
                                                    border: OutlineInputBorder(
                                                      borderRadius: BorderRadius.circular(12),
                                                      borderSide: BorderSide(
                                                        color: emailError ? errorColor : Colors.grey.shade300,
                                                        width: emailError ? 1.5 : 1,
                                                      ),
                                                    ),
                                                    focusedBorder: OutlineInputBorder(
                                                      borderRadius: BorderRadius.circular(12),
                                                      borderSide: BorderSide(
                                                        color: emailError ? errorColor : primaryColor,
                                                        width: 2,
                                                      ),
                                                    ),
                                                    errorBorder: OutlineInputBorder(
                                                      borderRadius: BorderRadius.circular(12),
                                                      borderSide: BorderSide(
                                                        color: errorColor,
                                                        width: 1.5,
                                                      ),
                                                    ),
                                                    filled: true,
                                                    fillColor: emailError 
                                                      ? errorColor.withOpacity(0.03) 
                                                      : Colors.grey.shade50,
                                                    contentPadding: const EdgeInsets.symmetric(
                                                      horizontal: 16,
                                                      vertical: 18,
                                                    ),
                                                  ),
                                                  keyboardType: TextInputType.emailAddress,
                                                  textInputAction: TextInputAction.next,
                                                  onChanged: (_) => _validateField('email'),
                                                  validator: (value) {
                                                    if (value == null || value.isEmpty) {
                                                      return 'Please enter your email';
                                                    }
                                                    if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)) {
                                                      return 'Please enter a valid email';
                                                    }
                                                    return null;
                                                  },
                                                ),
                                                // 🔽 Validation Message
                                                if (emailError)
                                                  Padding(
                                                    padding: const EdgeInsets.only(top: 4, left: 4),
                                                    child: Text(
                                                      'Email is required',
                                                      style: TextStyle(
                                                        fontSize: 12,
                                                        color: errorColor,
                                                        fontWeight: FontWeight.w500,
                                                      ),
                                                    ),
                                                  ),
                                              ],
                                            ),
                                            
                                            const SizedBox(height: 20),
                                            
                                            // Password Field with Validation
                                            Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                TextFormField(
                                                  controller: passCtrl,
                                                  decoration: InputDecoration(
                                                    labelText: 'Password',
                                                    labelStyle: labelStyle,
                                                    prefixIcon: Icon(Icons.lock_outline, color: textSecondary),
                                                    suffixIcon: IconButton(
                                                      icon: Icon(
                                                        obscurePassword 
                                                          ? Icons.visibility_outlined 
                                                          : Icons.visibility_off_outlined,
                                                        color: textSecondary,
                                                      ),
                                                      onPressed: () {
                                                        setState(() {
                                                          obscurePassword = !obscurePassword;
                                                        });
                                                      },
                                                    ),
                                                    border: OutlineInputBorder(
                                                      borderRadius: BorderRadius.circular(12),
                                                      borderSide: BorderSide(
                                                        color: passwordError ? errorColor : Colors.grey.shade300,
                                                        width: passwordError ? 1.5 : 1,
                                                      ),
                                                    ),
                                                    focusedBorder: OutlineInputBorder(
                                                      borderRadius: BorderRadius.circular(12),
                                                      borderSide: BorderSide(
                                                        color: passwordError ? errorColor : primaryColor,
                                                        width: 2,
                                                      ),
                                                    ),
                                                    errorBorder: OutlineInputBorder(
                                                      borderRadius: BorderRadius.circular(12),
                                                      borderSide: BorderSide(
                                                        color: errorColor,
                                                        width: 1.5,
                                                      ),
                                                    ),
                                                    filled: true,
                                                    fillColor: passwordError 
                                                      ? errorColor.withOpacity(0.03) 
                                                      : Colors.grey.shade50,
                                                    contentPadding: const EdgeInsets.symmetric(
                                                      horizontal: 16,
                                                      vertical: 18,
                                                    ),
                                                  ),
                                                  obscureText: obscurePassword,
                                                  textInputAction: TextInputAction.done,
                                                  onChanged: (_) => _validateField('password'),
                                                  validator: (value) {
                                                    if (value == null || value.isEmpty) {
                                                      return 'Please enter your password';
                                                    }
                                                    if (value.length < 6) {
                                                      return 'Password must be at least 6 characters';
                                                    }
                                                    return null;
                                                  },
                                                  onFieldSubmitted: (_) => login(),
                                                ),
                                                // 🔽 Validation Message
                                                if (passwordError)
                                                  Padding(
                                                    padding: const EdgeInsets.only(top: 4, left: 4),
                                                    child: Text(
                                                      'Password is required',
                                                      style: TextStyle(
                                                        fontSize: 12,
                                                        color: errorColor,
                                                        fontWeight: FontWeight.w500,
                                                      ),
                                                    ),
                                                  ),
                                              ],
                                            ),
                                            
                                            const SizedBox(height: 8),
                                            
                                            // Forgot Password - 🔽 أكثر هدوءًا
                                            Align(
                                              alignment: Alignment.centerRight,
                                              child: TextButton(
                                                onPressed: () {
                                                  // Implement forgot password
                                                },
                                                style: TextButton.styleFrom(
                                                  padding: EdgeInsets.zero,
                                                  minimumSize: Size.zero,
                                                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                                ),
                                                child: Text(
                                                  'Forgot Password?',
                                                  style: TextStyle(
                                                    fontSize: 13, // 🔽 أصغر
                                                    color: subtleBlue, // 🔽 أهدى
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            
                                            const SizedBox(height: 24),
                                            
                                            // Error Message
                                            if (error != null)
                                              Container(
                                                width: double.infinity,
                                                padding: const EdgeInsets.all(16),
                                                decoration: BoxDecoration(
                                                  color: errorColor.withOpacity(0.1),
                                                  borderRadius: BorderRadius.circular(12),
                                                  border: Border.all(color: errorColor.withOpacity(0.3)),
                                                ),
                                                child: Row(
                                                  children: [
                                                    Icon(Icons.error_outline, color: errorColor, size: 20),
                                                    const SizedBox(width: 12),
                                                    Expanded(
                                                      child: Text(
                                                        error!,
                                                        style: const TextStyle(
                                                          color: errorColor,
                                                          fontWeight: FontWeight.w500,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            
                                            if (error != null) const SizedBox(height: 24),
                                            
                                            // Login Button with Custom Loading Animation
                                            SizedBox(
                                              width: double.infinity,
                                              height: 56,
                                              child: loading
                                                ? ElevatedButton(
                                                    onPressed: null,
                                                    style: ElevatedButton.styleFrom(
                                                      backgroundColor: primaryColor,
                                                      shape: RoundedRectangleBorder(
                                                        borderRadius: BorderRadius.circular(12),
                                                      ),
                                                      elevation: 0,
                                                    ),
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                      children: [
                                                        SizedBox(
                                                          width: 20,
                                                          height: 20,
                                                          child: CircularProgressIndicator(
                                                            strokeWidth: 2,
                                                            valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                                          ),
                                                        ),
                                                        const SizedBox(width: 12),
                                                        Text(
                                                          'Signing In...',
                                                          style: buttonStyle.copyWith(fontSize: 15),
                                                        ),
                                                      ],
                                                    ),
                                                  )
                                                : ElevatedButton(
                                                    onPressed: login,
                                                    style: ElevatedButton.styleFrom(
                                                      backgroundColor: primaryColor,
                                                      foregroundColor: Colors.white,
                                                      shape: RoundedRectangleBorder(
                                                        borderRadius: BorderRadius.circular(12),
                                                      ),
                                                      elevation: 0,
                                                      padding: const EdgeInsets.symmetric(vertical: 16),
                                                      shadowColor: primaryColor.withOpacity(0.3),
                                                    ),
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                      children: [
                                                        Text('Sign In', style: buttonStyle),
                                                        const SizedBox(width: 12),
                                                        Icon(Icons.arrow_forward, size: 20),
                                                      ],
                                                    ),
                                                  ),
                                            ),
                                            
                                            const SizedBox(height: 32),
                                            
                                            // Divider
                                            Row(
                                              children: [
                                                Expanded(child: Divider(color: Colors.grey.shade300)),
                                                Padding(
                                                  padding: const EdgeInsets.symmetric(horizontal: 16),
                                                  child: Text(
                                                    'New to PowerMonitor?',
                                                    style: subtitleStyle.copyWith(fontSize: 14),
                                                  ),
                                                ),
                                                Expanded(child: Divider(color: Colors.grey.shade300)),
                                              ],
                                            ),
                                            
                                            const SizedBox(height: 24),
                                            
                                            // Register Button
                                            OutlinedButton(
                                              onPressed: loading ? null : () {
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (_) => const RegisterScreen(),
                                                  ),
                                                );
                                              },
                                              style: OutlinedButton.styleFrom(
                                                foregroundColor: primaryColor,
                                                side: BorderSide(color: primaryColor),
                                                shape: RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.circular(12),
                                                ),
                                                padding: const EdgeInsets.symmetric(vertical: 16),
                                                minimumSize: const Size(double.infinity, 56),
                                              ),
                                              child: Text(
                                                'Create Account',
                                                style: buttonStyle.copyWith(color: primaryColor),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          
                          // Footer
                          const SizedBox(height: 40),
                          Align(
                            alignment: Alignment.center,
                            child: Text(
                              '© 2024 PowerMonitor Network. All rights reserved.',
                              style: subtitleStyle.copyWith(fontSize: 12),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      );
    }

  Widget _buildBrandingSection(bool isMobile) {
    return Center(
      child: Column(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [primaryColor, secondaryColor],
              ),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(Icons.bolt, color: Colors.white),
          ),
          const SizedBox(height: 12),
          Text(
            'PowerMonitor',
            style: TextStyle(
              fontSize: isMobile ? 22 : 24,
              fontWeight: FontWeight.w800,
              color: textPrimary,
            ),
          ),
        ],
      ),
    );
  }
  }