import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../screens/ble_dashboard_screen.dart';
import '../screens/ble_insecure_screen.dart';
import '../screens/notifications_screen.dart';
import '../services/notification_service.dart';
import '../models/app_notification.dart';

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() =>
      _MainNavigationScreenState();
}

class _MainNavigationScreenState
    extends State<MainNavigationScreen> {

  int currentIndex = 0;
  int notificationCount = 0;

  final List<Widget> screens = const [
    BleDashboardScreen(),
    BLEDoorScreen(),
    NotificationsScreen(),
  ];

  @override
  void initState() {
    super.initState();
    _loadNotificationCount();
  }

  Future<void> _loadNotificationCount() async {
    final notifications =
        await NotificationService.getNotifications();
    setState(() {
      notificationCount = notifications.length;
    });
  }

  Future<void> logout() async {
    await FirebaseAuth.instance.signOut();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF4361EE),

        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarColor: Colors.white,
          statusBarIconBrightness: Brightness.dark,
        ),

        title: Text(
          currentIndex == 0
              ? "Dashboard"
              : currentIndex == 1
                  ? "Smart Lock"
                  : "Notifications",
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),

        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: "Logout",
            onPressed: logout,
            color: Colors.white,
          ),
        ],
      ),

      body: screens[currentIndex],

      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentIndex,
        onTap: (index) async {
          setState(() {
            currentIndex = index;
          });

          if (index == 2) {
            await _loadNotificationCount();
          }
        },

        selectedItemColor: const Color(0xFF4361EE),

        items: [
          const BottomNavigationBarItem(
            icon: Icon(Icons.dashboard),
            label: "Dashboard",
          ),
          const BottomNavigationBarItem(
            icon: Icon(Icons.lock),
            label: "Smart Lock",
          ),

          BottomNavigationBarItem(
            icon: Stack(
              children: [
                const Icon(Icons.notifications),

                if (notificationCount > 0)
                  Positioned(
                    right: 0,
                    top: 0,
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: const BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                      ),
                      constraints: const BoxConstraints(
                        minWidth: 18,
                        minHeight: 18,
                      ),
                      child: Text(
                        notificationCount.toString(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
              ],
            ),
            label: "Notifications",
          ),
        ],
      ),
    );
  }
}
