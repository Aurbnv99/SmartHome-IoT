class HomeStatus {
  final String room; // room1 / room2 / room3

  final bool? lightOn;
  final bool? heaterOn;
  final double? temp;
  final int? humidity;
  final double? pressure;
  final String? door;


  const HomeStatus({
    required this.room,
    this.lightOn,
    this.heaterOn,
    this.temp,
    this.humidity,
    this.pressure,
    this.door,
  });

  // ================= JSON → Model =================
  factory HomeStatus.fromJson(Map<String, dynamic> json) {
    bool? parseBool(dynamic value) {
      if (value == null) return null;
      if (value is bool) return value;
      if (value is String) {
        if (value.toLowerCase() == "on") return true;
        if (value.toLowerCase() == "off") return false;
        if (value.toLowerCase() == "true") return true;
        if (value.toLowerCase() == "false") return false;
      }
      return null;
    }

    double? parseDouble(dynamic value) {
      if (value == null) return null;
      if (value is num) return value.toDouble();
      return null;
    }

    int? parseInt(dynamic value) {
      if (value == null) return null;
      if (value is num) return value.toInt();
      return null;
    }

    return HomeStatus(
      room: json['room']?.toString() ?? "unknown",

      lightOn: json.containsKey('light')
          ? parseBool(json['light'])
          : null,

      heaterOn: json.containsKey('heater')
          ? parseBool(json['heater'])
          : null,

      temp: json.containsKey('temperature')
          ? parseDouble(json['temperature'])
          : null,

      humidity: json.containsKey('humidity')
          ? parseInt(json['humidity'])
          : null,

      pressure: json.containsKey('pressure')
          ? parseDouble(json['pressure'])
          : null,
    );
  }

  // ================= Default values per room =================
  factory HomeStatus.initial(String room) {
    switch (room) {
      case "room1":
      case "room2":
        return HomeStatus(
          room: room,
          lightOn: false,
          heaterOn: false,
          temp: 56.0,
          humidity: 50,
          pressure: 1013.0,
        );

      case "room3":
        return HomeStatus(
          room: room,
          lightOn: false,
        );

      default:
        return HomeStatus(room: room);
    }
  }

  // ================= Model → JSON =================
  Map<String, dynamic> toJson() {
    return {
      'room': room,
      if (lightOn != null) 'light': lightOn! ? 'on' : 'off',
      if (heaterOn != null) 'heater': heaterOn! ? 'on' : 'off',
      if (temp != null) 'temperature': temp,
      if (humidity != null) 'humidity': humidity,
      if (pressure != null) 'pressure': pressure,
    };
  }

  // ================= copyWith =================
  HomeStatus copyWith({
    bool? lightOn,
    bool? heaterOn,
    double? temp,
    int? humidity,
    double? pressure,
  }) {
    return HomeStatus(
      room: room,
      lightOn: lightOn ?? this.lightOn,
      heaterOn: heaterOn ?? this.heaterOn,
      temp: temp ?? this.temp,
      humidity: humidity ?? this.humidity,
      pressure: pressure ?? this.pressure,
    );
  }

  // ================= Equality (important for UI performance) =================
  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is HomeStatus &&
        other.room == room &&
        other.lightOn == lightOn &&
        other.heaterOn == heaterOn &&
        other.temp == temp &&
        other.humidity == humidity &&
        other.pressure == pressure;
  }

  @override
  int get hashCode {
    return room.hashCode ^
        lightOn.hashCode ^
        heaterOn.hashCode ^
        temp.hashCode ^
        humidity.hashCode ^
        pressure.hashCode;
  }

  @override
  String toString() {
    return 'HomeStatus(room: $room, light: $lightOn, heater: $heaterOn, temp: $temp, humidity: $humidity, pressure: $pressure)';
  }
}
